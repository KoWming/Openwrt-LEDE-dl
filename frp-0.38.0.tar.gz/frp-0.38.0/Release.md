### New

* Add `/healthz` API.
* frpc support `disable_custom_tls_first_byte` .If set true, frpc will not send custom header byte.

### Improve

* Use go standard embed package instead of statik.
