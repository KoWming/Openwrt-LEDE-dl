package metrics

import (
	"github.com/fatedier/frp/pkg/metrics/aggregate"
)

var EnableMem = aggregate.EnableMem
var EnablePrometheus = aggregate.EnablePrometheus
