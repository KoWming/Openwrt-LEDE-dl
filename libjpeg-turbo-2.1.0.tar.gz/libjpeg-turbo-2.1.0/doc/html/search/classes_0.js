var searchData=
[
  ['tjregion_111',['tjregion',['../structtjregion.html',1,'']]],
  ['tjscalingfactor_112',['tjscalingfactor',['../structtjscalingfactor.html',1,'']]],
  ['tjtransform_113',['tjtransform',['../structtjtransform.html',1,'']]]
];
