package test_pack_init

// This is a placeholder package for a test on specific race detector report on
// default Options initialization.
