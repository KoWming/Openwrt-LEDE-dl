package x

// import _ "net/http/pprof"

func init() {
	// log.SetFlags(log.LstdFlags | log.Lshortfile)
	// go func() {
	// 	log.Println(http.ListenAndServe(":6060", nil))
	// }()
}
