#!/bin/bash -eu

go test -bench=.
