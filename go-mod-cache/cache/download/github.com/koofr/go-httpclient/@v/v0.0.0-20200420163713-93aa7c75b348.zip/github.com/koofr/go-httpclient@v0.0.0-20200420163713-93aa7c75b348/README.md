go-httpclient
=============

![Test](https://github.com/koofr/go-httpclient/workflows/Test/badge.svg)

Go HTTP client.

[![GoDoc](https://godoc.org/github.com/koofr/go-httpclient?status.png)](https://godoc.org/github.com/koofr/go-httpclient)

## Install

    go get github.com/koofr/go-httpclient

## Testing

    go get -t
    go test
