# go-acd [![Build Status](https://travis-ci.org/sgeb/go-acd.svg?branch=master)](https://travis-ci.org/sgeb/go-acd)

Go library for accessing the Amazon Cloud Drive.

This library is the basis for [`acdcli`](https://github.com/sgeb/acdcli).

Still work in progress. Focusing on read-only operations at first. Refer to the
[milestones](https://github.com/sgeb/go-acd/milestones) and
[issues](https://github.com/sgeb/go-acd/issues) for planned features.
