package netfilter

//go:generate stringer -type=ProtoFamily
//go:generate stringer -type=SubsystemID
