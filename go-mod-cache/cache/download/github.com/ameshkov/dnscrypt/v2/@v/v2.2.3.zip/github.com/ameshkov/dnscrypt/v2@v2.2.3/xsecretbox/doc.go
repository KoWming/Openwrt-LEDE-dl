// Package xsecretbox implements encryption/decryption of a message using specified keys
package xsecretbox
