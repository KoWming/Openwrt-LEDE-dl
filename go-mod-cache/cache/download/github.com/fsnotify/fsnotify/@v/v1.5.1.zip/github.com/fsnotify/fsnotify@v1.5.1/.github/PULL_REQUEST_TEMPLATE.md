NOTE: Please do not open a pull request that adds or changes the public API without giving consideration to all supported operating systems.

#### What does this pull request do?


#### Where should the reviewer start?


#### How should this be manually tested?

