bcrypt_pbkdf
============

Go implementation of OpenBSD's bcrypt_pbkdf(3)
