package utils

// ContextKey is the type that used for saving and restoring value in context.
type ContextKey string
