# go-shared

[![Build Status](https://travis-ci.org/pengsrc/go-shared.svg?branch=master)](https://travis-ci.org/pengsrc/go-shared)
[![Go Report Card](https://goreportcard.com/badge/github.com/pengsrc/go-shared)](https://goreportcard.com/report/github.com/pengsrc/go-shared)
[![License](http://img.shields.io/badge/license-apache%20v2-blue.svg)](https://github.com/pengsrc/go-shared/blob/master/LICENSE)

Useful packages for the Go programming language.

## Contributing

1. Fork it ( https://github.com/pengsrc/go-shared/fork )
2. Create your feature branch (`git checkout -b new-feature`)
3. Commit your changes (`git commit -asm 'Add some feature'`)
4. Push to the branch (`git push origin new-feature`)
5. Create a new Pull Request

## License

The Apache License (Version 2.0, January 2004).
