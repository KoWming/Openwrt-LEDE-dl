# GoFork

This repository contains modified Go standard library packages for use as work arounds until issues are addressed in the official distribution.

There is no support for these packages.

These packages should not be generally used. Use the official Go packages instead.