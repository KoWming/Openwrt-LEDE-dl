Please fill out the sections below to help us address your issue.

### Version of AWS SDK for Go?


### Version of Go (`go version`)?


### What issue did you see?

### Steps to reproduce

If you have an runnable example, please include it.

