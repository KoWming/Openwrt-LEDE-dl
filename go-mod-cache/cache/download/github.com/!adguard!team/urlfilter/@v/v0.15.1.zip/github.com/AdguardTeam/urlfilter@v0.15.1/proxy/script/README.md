# Content Script

Content script's purpose is to apply cosmetic rules to the page.

### Scripts

* `yarn install` - installs dependencies.
* `yarn run build` - build the content script to the `dist` folder.
* `yarn run generate` - generate a .go file with the content script template.