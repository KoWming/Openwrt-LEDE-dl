module.exports = {
    outputDir: 'dist',
    goTemplatePath: '../pages_tmpl.go',
};
