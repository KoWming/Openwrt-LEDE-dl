// Package filterlist provides methods to work with filter lists.
package filterlist
