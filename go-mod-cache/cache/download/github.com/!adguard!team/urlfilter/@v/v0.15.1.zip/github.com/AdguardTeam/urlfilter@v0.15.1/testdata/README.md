Resources for benchmarking tests.

Please note, that "requests.json.zip" is not the full version of the file.

You can download the full version from here:
https://cdn.cliqz.com/adblocking/requests_top500.json.gz

Here you can read more about how these requests were crawled:
https://github.com/cliqz-oss/adblocker