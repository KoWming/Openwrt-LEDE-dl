// Package urlfilter contains implementation of AdGuard content blocking engine
package urlfilter
