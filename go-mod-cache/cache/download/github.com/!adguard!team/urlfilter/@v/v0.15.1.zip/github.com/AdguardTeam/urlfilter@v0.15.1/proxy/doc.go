// Package proxy contains implementation of the filtering MITM proxy
package proxy
