// Package rules contains implementation of all kinds of blocking rules
package rules
