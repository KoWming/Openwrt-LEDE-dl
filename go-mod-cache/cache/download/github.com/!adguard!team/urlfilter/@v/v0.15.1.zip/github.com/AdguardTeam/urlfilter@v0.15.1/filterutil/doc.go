// Package filterutil contains helper functions used by urlfilter
package filterutil
