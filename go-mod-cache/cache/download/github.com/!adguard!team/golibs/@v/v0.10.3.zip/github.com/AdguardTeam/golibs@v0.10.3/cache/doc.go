// Package cache provides a simple LRU cache implementation
package cache
