[![Code Coverage](https://img.shields.io/codecov/c/github/AdguardTeam/golibs/master.svg)](https://codecov.io/github/AdguardTeam/golibs?branch=master)
[![Go Report Card](https://goreportcard.com/badge/github.com/AdguardTeam/golibs)](https://goreportcard.com/report/AdguardTeam/golibs)
[![Go Reference](https://pkg.go.dev/badge/github.com/AdguardTeam/golibs.svg)](https://pkg.go.dev/github.com/AdguardTeam/golibs)

 #  `golibs`

Go utility packages primarily used in AdGuard projects.  See the documentation
for individual packages' on pkg.go.dev for more information and examples.
