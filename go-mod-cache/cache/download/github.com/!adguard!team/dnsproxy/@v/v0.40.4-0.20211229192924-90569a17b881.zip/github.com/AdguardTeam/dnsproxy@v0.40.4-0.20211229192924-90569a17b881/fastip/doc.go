// Package fastip implements the algorithm that allows to
// query multiple resolvers, ping all IP addresses that were returned,
// and return the fastest one among them.
package fastip
