// +build go1.18

package qtls

var _ int = "quic-go doesn't build on Go 1.18 yet."
