// Package sys provide convenient wrappers around syscalls.
package sys
