package shell

import "testing"

func TestShell(t *testing.T) {
	// TODO(xiaq): Add tests.
}
