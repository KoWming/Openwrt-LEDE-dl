// Package highlight implements syntax highlighting for Elvish code.
package highlight
