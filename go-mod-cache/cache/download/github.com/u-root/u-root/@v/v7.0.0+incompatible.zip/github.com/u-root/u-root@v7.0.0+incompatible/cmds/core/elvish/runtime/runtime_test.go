package runtime

import "testing"

func TestRuntime(t *testing.T) {
	// TODO(xiaq): Add tests.
}
