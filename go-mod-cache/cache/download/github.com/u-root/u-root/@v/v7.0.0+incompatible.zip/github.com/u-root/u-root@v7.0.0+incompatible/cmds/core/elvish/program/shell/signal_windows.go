package shell

import (
	"os"
)

func handleSignal(_ os.Signal) {
}
