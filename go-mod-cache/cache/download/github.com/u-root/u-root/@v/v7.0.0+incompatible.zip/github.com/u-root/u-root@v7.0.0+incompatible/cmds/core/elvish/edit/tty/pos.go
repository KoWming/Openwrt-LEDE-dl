package tty

// Pos is the position in a terminal.
type Pos struct {
	line, col int
}
