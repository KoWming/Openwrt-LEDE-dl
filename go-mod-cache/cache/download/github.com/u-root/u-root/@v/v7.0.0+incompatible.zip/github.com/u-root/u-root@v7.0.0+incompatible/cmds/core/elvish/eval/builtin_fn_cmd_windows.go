package eval

var (
	execFn = notSupportedOnWindows
	fg     = notSupportedOnWindows
)
