package storedefs

import "testing"

func TestStoreDefs(t *testing.T) {
	// TODO(xiaq): Add tests
}
