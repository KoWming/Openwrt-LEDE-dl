package prompt

import "testing"

func TestPrompt(t *testing.T) {
	// TODO(xiaq): Add tests.
}
