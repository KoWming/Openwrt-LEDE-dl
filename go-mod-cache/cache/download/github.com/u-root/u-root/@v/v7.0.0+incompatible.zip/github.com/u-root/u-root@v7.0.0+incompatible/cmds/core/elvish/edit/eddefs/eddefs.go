// Package eddefs contains types used in the Editor. It is separate package so
// that editor plugins do not need to depend on the edit package.
package eddefs
