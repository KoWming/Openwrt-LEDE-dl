// Package util contains utility functions.
package util
