package eval

import "testing"

func TestBuiltinFnCmd(t *testing.T) {
	runTests(t, []Test{})
}
