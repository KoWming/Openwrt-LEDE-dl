package ui

var (
	styleForMode   = Styles{"bold", "lightgray", "bg-magenta"}
	styleForFilter = Styles{"underlined"}

	styleForScrollBarArea  = Styles{"magenta"}
	styleForScrollBarThumb = Styles{"magenta", "inverse"}
)
