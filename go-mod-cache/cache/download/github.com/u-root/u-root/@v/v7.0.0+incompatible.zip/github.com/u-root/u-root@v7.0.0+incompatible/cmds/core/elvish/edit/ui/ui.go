// Package ui contains types that may be used by different editor frontends.
package ui
