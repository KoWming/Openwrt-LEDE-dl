// Package tty provides terminal functionality for the Elvish editor.
package tty

import "github.com/u-root/u-root/cmds/core/elvish/util"

var logger = util.GetLogger("[edit/tty] ")
