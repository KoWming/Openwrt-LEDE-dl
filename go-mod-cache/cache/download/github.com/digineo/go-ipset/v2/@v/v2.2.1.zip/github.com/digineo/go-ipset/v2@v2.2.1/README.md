go-ipset
========

[![CircleCI](https://circleci.com/gh/digineo/go-ipset.svg?style=shield)](https://circleci.com/gh/digineo/go-ipset)
[![Codecov](http://codecov.io/github/digineo/go-ipset/coverage.svg?branch=master)](http://codecov.io/github/digineo/go-ipset?branch=master)
[![Go Report Card](https://goreportcard.com/badge/github.com/digineo/go-ipset)](https://goreportcard.com/report/github.com/digineo/go-ipset)
