package dhcpv4

const (
	ServerPort = 67
	ClientPort = 68
)
