// +build ignore

package main

import "fmt"

func main() {
	fmt.Printf("%q%c\n", 3, false)
}
