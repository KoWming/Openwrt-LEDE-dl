# Generating PowerShell Completions For Your Own cobra.Command

Please refer to [Shell Completions](shell_completions.md#powershell-completions) for details.
