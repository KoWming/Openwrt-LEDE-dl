# go4.org/intern

See https://godoc.org/go4.org/intern

