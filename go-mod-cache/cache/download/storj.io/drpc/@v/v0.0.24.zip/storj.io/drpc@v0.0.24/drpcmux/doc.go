// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpcmux is a handler to dispatch rpcs to implementations.
package drpcmux
