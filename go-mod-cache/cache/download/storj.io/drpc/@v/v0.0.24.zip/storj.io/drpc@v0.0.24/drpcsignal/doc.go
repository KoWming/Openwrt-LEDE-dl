// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpcsignal holds a helper type to signal errors.
package drpcsignal
