// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpcerr lets one associate error codes with errors.
package drpcerr
