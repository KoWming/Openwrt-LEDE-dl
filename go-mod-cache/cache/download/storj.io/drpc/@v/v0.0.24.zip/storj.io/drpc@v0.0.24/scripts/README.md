# scripts

This folder contains some useful scripts for the repository.
