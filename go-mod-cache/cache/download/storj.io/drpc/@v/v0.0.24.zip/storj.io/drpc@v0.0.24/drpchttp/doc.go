// Copyright (C) 2021 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpchttp implements a net/http handler for unitary RPCs.
package drpchttp
