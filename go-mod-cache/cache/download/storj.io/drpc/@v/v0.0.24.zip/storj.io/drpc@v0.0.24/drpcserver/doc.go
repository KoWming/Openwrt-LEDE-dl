// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpcserver allows one to execute registered rpcs.
package drpcserver
