# package protoc-gen-go-drpc

`import "storj.io/drpc/cmd/protoc-gen-go-drpc"`



## Usage
