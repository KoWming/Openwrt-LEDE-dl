// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpc is a light replacement for gprc.
package drpc
