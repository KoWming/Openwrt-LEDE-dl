// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpcmetadata define the structure of the metadata supported by drpc library.
package drpcmetadata
