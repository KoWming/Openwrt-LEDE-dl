// Copyright (C) 2021 Storj Labs, Inc.
// See LICENSE for copying information.

// Package drpcenc holds some helper functions for encoding messages.
package drpcenc
