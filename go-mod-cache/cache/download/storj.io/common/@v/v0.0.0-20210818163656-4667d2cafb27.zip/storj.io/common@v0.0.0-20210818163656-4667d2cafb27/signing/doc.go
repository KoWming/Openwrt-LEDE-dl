// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package signing implements consistent signing and verifying protobuf messages.
package signing
