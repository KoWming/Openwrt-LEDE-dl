// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

package netutil

import "github.com/spacemonkeygo/monkit/v3"

var mon = monkit.Package()
