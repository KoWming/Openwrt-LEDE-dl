// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package ranger implements lazy io.Reader and io.Writer interfaces.
package ranger
