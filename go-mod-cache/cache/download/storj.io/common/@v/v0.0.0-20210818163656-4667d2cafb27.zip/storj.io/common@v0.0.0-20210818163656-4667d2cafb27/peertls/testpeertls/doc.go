// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package testpeertls implements testing utilities for peertls.
package testpeertls
