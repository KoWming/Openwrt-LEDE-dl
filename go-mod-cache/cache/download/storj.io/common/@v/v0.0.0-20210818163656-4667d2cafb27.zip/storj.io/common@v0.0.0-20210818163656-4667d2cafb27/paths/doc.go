// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package paths implements wrappers for handling encrypted and unencrypted
// paths safely.
package paths
