// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package tlsopts handles TLS server options.
package tlsopts
