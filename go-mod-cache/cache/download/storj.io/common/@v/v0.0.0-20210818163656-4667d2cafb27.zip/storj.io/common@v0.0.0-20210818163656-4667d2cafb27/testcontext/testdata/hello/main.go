// Copyright (C) 2021 Storj Labs, Inc.
// See LICENSE for copying information.

package main

func main() { println("hello") }
