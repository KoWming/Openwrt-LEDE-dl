// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package pb contains protobuf definitions for Storj peers.
package pb

//go:generate go run gen.go
