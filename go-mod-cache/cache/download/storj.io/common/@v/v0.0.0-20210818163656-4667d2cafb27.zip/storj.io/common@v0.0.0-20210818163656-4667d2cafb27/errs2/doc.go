// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package errs2 collects common error handling functions.
package errs2
