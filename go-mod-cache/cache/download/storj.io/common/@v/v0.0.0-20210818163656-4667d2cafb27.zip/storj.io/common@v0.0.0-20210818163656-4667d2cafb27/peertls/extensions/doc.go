// Copyright (C) 2020 Storj Labs, Inc.
// See LICENSE for copying information.

// Package extensions contains extensions to TLS certificate handling.
package extensions
