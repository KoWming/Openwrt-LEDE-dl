// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// Package storj contains the types which represent the main entities of the Storj domain.
package storj
