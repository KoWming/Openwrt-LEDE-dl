// Copyright (C) 2019 Storj Labs, Inc.
// See LICENSE for copying information.

// +build !race

package testcontext

const raceEnabled = false
