package fuse

func openFlags(flags uint32) OpenFlags {
	return OpenFlags(flags)
}
