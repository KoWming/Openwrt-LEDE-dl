package fuse

func daemonTimeout(name string) MountOption {
	return dummyOption
}
