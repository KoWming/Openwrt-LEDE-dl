// Package httpjson helps transporting JSON over HTTP.
//
// This might get extracted to a standalone repository, if it proves
// useful enough.
package httpjson
